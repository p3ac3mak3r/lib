using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Admin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=DATASERVER;database=shoppingmall;user id=sa;password=sqlserver");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Btnenter_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("Select * from admin where uname='" + Txtuname.Text + "'and password='" + Txtpwd.Text + "'", con);
        SqlDataReader dr;
        con.Open();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Response.Redirect("AdminDb.aspx");
        }
        else
        {
            Response.Write("Enter correct username or password");
        }
        con.Close();
    }
    
}

