using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Buy : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;server=DATASERVER;");
    //static int i;
     int total = 0;
    protected void Page_Load(object sender, EventArgs e)

    {
        if (!Page.IsPostBack)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("Home.aspx");
            }

            BindGrid();
            Response.Buffer = true;
            Response.ExpiresAbsolute = DateTime.Now.AddDays(-1d);
            Response.Expires = -1500;
            Response.CacheControl = "no-cache";
        }
        //int i = Convert.ToInt32(Session["UserId"]);
        //conn.Open();
        //SqlDataAdapter da = new SqlDataAdapter("select * from cart where UserId='" + i + "'", conn);
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //GridView1.DataSource = ds;
        //GridView1.DataBind();
        //conn.Close();

    }

    void BindGrid()
    {
        string UserId = Session["UserId"].ToString();
        string strCartSQL = "Select * from cart where UserId='" + UserId + "'";
        SqlDataAdapter da = new SqlDataAdapter(strCartSQL, conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "Cart");
        GridView1.DataSource = ds.Tables["Cart"].DefaultView;
        GridView1.DataBind();
    }

    protected void Btndelete_Click(object sender, EventArgs e)
    {
        //if (!Page.IsPostBack)
        
            for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                //CheckBox cbx=null;
                //if checkbox in 0th row
                //ContentPlaceHolder cph = (ContentPlaceHolder)Page.Master.FindControl("ContentPlaceHolder1");
                //GridView gv = (GridView)cph.FindControl("GridView1");

                CheckBox cbx = ((CheckBox)GridView1.Rows[i].Cells[i].FindControl("CheckBox1"));
                if (cbx != null)
                {
                    if (cbx.Checked)
                    {

                        string UserId = Session["UserId"].ToString();
                        string pid = ((Label)GridView1.Rows[i].FindControl("Label3")).Text;
                        DeleteData("Delete from cart where Pid="+pid+" and UserID="+UserId+"");
                        //string cmd="INSERT INTO database(a,b) VALUES('{0},'{1})",gridView.rows[i].cells[1].text,gridView.rows[i].cells[2].text,;
                        //insert(cmd);
                        Response.Write("<script> confirm('Record deleted sucessfully') </script>");
                    }
                }
            }
            //GridView1.DataBind();
            BindGrid();
        }
    

    public int DeleteData(string DeleteSQL)
    {
        SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;data source=DATASERVER");
        SqlCommand cmd = new SqlCommand(DeleteSQL,conn);
        conn.Open();
        int result = cmd.ExecuteNonQuery();
        conn.Close();
        return result;
    }


    

    protected void Btncost_Click1(object sender, EventArgs e)
    {
        for (int i = 0; i < GridView1.Rows.Count; i++)
        {
            //if checkbox in 0th row
            CheckBox cbx = ((CheckBox)GridView1.Rows[i].Cells[i].FindControl("CheckBox1"));
            if (cbx != null)
            {
                if (cbx.Checked)
                {
                    total = total + Convert.ToInt32(((Label)GridView1.Rows[i].Cells[i].FindControl("Label5")).Text);
                }
            }
        }

        Lblcost.Text = "The Total Price is " + Convert.ToString(total);
    }
    protected void Btnlogout_Click(object sender, EventArgs e)
    {
        Session["UserId"] = null;
        Response.Redirect("Userlogin.aspx");
    }
}