using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Itemsdisplay : System.Web.UI.Page
{
   static  string UserId;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string Producttype = Request.QueryString["Producttype"].ToString();
            SqlDataSource1.SelectCommand = "SELECT * FROM [Products] WHERE Producttype='" + Producttype + "'";
            GridView1.DataBind();
        }

        this.Title =  Session["UserId"].ToString(); 
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Btnadd_Click (object sender, EventArgs e)
    {
        
        for(int i=0;i<GridView1.Rows.Count;i++)
        {
            //CheckBox cbx=null;
             //if checkbox in 0th row
            //ContentPlaceHolder cph = (ContentPlaceHolder)Page.Master.FindControl("ContentPlaceHolder1");
            //GridView gv = (GridView)cph.FindControl("GridView1");
            CheckBox cbx = ((CheckBox)GridView1.Rows[i].Cells[i].FindControl("CheckBox1"));
        
          
             if(cbx!=null)
             {
               if(cbx.Checked)
               {

                       UserId = Session["UserId"].ToString ();
                      string pid =   ((Label)GridView1.Rows [i].FindControl ("Label1")).Text;
                      string image = (((Image)GridView1.Rows[i].FindControl("Image1"))).ImageUrl.ToString();
                      string price = ((Label)GridView1.Rows[i].FindControl("Label4")).Text;
                      InsertData("insert into cart(UserId,Pid,image,price)values('"+ UserId +"','" + pid  + "','" + image + "','"+price+"')");
                      //string cmd="INSERT INTO database(a,b) VALUES('{0},'{1})",gridView.rows[i].cells[1].text,gridView.rows[i].cells[2].text,;
                     //insert(cmd);
                      Response.Write("<script> confirm('Record inserted sucessfully') </script>");
                      //Response.Redirect("Buy.aspx");
               }
             }
             }
    
    }

    public int InsertData(string insertSQL)
    {
        SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;data source=DATASERVER");
        SqlCommand cmd = new SqlCommand(insertSQL,conn);
        conn.Open();
        int result = cmd.ExecuteNonQuery();
        conn.Close();
        return result;
    }

    protected void Btnshow_Click(object sender, EventArgs e)
    {
        //SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;data source=DATASERVER");
        //conn.Open();
        //SqlCommand cmd1 = new SqlCommand("select * from cart where UserId='" + UserId + "'", conn);
        //cmd1.ExecuteReader();
        //conn.Close();
        //Response.Redirect("Buy.aspx");
    }
}


