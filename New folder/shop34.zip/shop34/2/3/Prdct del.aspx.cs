using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Prdct_del : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;server=DATASERVER;");
    protected void Page_Load(object sender, EventArgs e)
    {
        BindGrid();
        if (!Page.IsPostBack)
        {
            string Producttype = Request.QueryString["Producttype"].ToString();
            SqlDataSource1.SelectCommand = "SELECT * FROM [Products] WHERE Producttype='" + Producttype + "'";
            
            GridView1.DataBind();
        }
    }
    void BindGrid()
    {

        string productSQL = "Select * from products";
        SqlDataAdapter da = new SqlDataAdapter(productSQL, conn);
        DataSet ds = new DataSet();
        da.Fill(ds, "products");
        GridView1.DataSource = ds.Tables["products"].DefaultView;
        GridView1.DataBind();
    }
    protected void Btndelete_Click(object sender, EventArgs e)
    {
        for (int i = 0; i < GridView1.Rows.Count; i++)
            {
                
                CheckBox cbx = ((CheckBox)GridView1.Rows[i].Cells[i].FindControl("CheckBox1"));
                if (cbx != null)
                {
                    if (cbx.Checked)
                    {

                       
                        string pid = ((Label)GridView1.Rows[i].FindControl("Label3")).Text;
                        DeleteData("Delete from products where Pid="+pid+" ");
                        
                        Response.Write("<script> confirm('Record deleted sucessfully') </script>");
                    }
                }
            }
            
            BindGrid();
        }
    

    public int DeleteData(string DeleteSQL)
    {
        SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;data source=DATASERVER");
        SqlCommand cmd = new SqlCommand(DeleteSQL,conn);
        conn.Open();
        int result = cmd.ExecuteNonQuery();
        conn.Close();
        return result;
    }

    }

