using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Change_Pwd : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;server=DATASERVER;");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        string Uname = TextBox1.Text;
        string Password = TextBox2.Text;
        string npwd = TextBox3.Text;
        
        SqlCommand cmd = new SqlCommand("update login set Password='" + npwd + "' where Uname='" + TextBox1.Text + "' and Password='" + TextBox2.Text + "'", con);
        Label1.Text = "Enter correct userid or Password";
        cmd.ExecuteNonQuery();
        con.Close();
    }
}
