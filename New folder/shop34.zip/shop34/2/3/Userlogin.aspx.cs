using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Userlogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=DATASERVER;database=shoppingmall;user id=sa;password=sqlserver");
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Btnlogin_Click(object sender, EventArgs e)
    {
        SqlCommand cmd=new SqlCommand("Select * from Login where uname='"+Txtuname.Text+"'and password='"+Txtpassword.Text+"'",con);
        SqlDataReader dr;
        con.Open();
        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            dr.Close();
            SqlCommand cmd1= new SqlCommand("select UserId from login where Uname='" + Txtuname.Text + "'and Password='" + Txtpassword.Text + "'", con);
            SqlDataReader dr1;
            dr1 = cmd1.ExecuteReader();
            if (dr1.Read())
            {
                Label1.Text = dr1[0].ToString();
                //int i = dr1;
                Session["UserId"] = Label1.Text;
                //Response.Redirect("Itemsdisplay.aspx");
                dr1.Close();
            }
            Response.Redirect("Products.aspx");
        }
        else
        {
            Response.Write("Enter correct username or password");
        }
    }
}
