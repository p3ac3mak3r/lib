using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class paypal : System.Web.UI.Page
{
    SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;server=DATASERVER;");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            if (Session["UserId"] == null)
            {
                Response.Redirect("Home.aspx");
            }

            //BindGrid();
            Response.Buffer = true;
            Response.ExpiresAbsolute = DateTime.Now.AddDays(-1d);
            Response.Expires = -1500;
            Response.CacheControl = "no-cache";
        }
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        string UserId = Session["UserId"].ToString();
        DeleteData("Delete from cart where  UserID=" + UserId + "");
        Response.Write("<script> confirm('you are purchasing your selected items') </script>");

    }
    public int DeleteData(string DeleteSQL)
    {
        SqlConnection conn = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;data source=DATASERVER");
        SqlCommand cmd = new SqlCommand(DeleteSQL, conn);
        conn.Open();
        int result = cmd.ExecuteNonQuery();
        conn.Close();
        return result;
    }
    protected void Btnlogout_Click(object sender, EventArgs e)
    {
        Session["UserId"] = null;
        Response.Redirect("Userlogin.aspx");
    }
}
