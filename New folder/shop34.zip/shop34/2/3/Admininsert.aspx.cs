using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Adminlogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=DATASERVER;database=shoppingmall;user id=sa;password=sqlserver");
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select pid from products", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        con.Close();
        int i = GridView1.Rows.Count;
        i++;
        ViewState["pid"] = i;
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {


        int j = (int)ViewState["pid"];
        con.Open();
       
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(Server.MapPath("~/images/") + FileUpload1.FileName);
            string s = "~/images/" + FileUpload1.FileName;


            SqlCommand cmd = new SqlCommand("insert into products values('" + j + "','" + TextBox1.Text + "','" + ddl.Text + "','" + s + "','"+Convert.ToInt32( TextBox2.Text)+"')", con);
            cmd.ExecuteNonQuery();

            //SqlCommand cmd1 = new SqlCommand("insert into dummy values('" + j + "')", con);
            //cmd1.ExecuteNonQuery();
        }
        con.Close();
    }
}
