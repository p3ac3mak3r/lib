using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class forgotpwd : System.Web.UI.Page
{
  //SqlConnection con = new SqlConnection("server=localhost;database=shoppingmall;trusted_connection=true");
    protected void Page_Load(object sender, EventArgs e)
    {
        Lblpwd.Visible = false;
        Txtpwd.Visible = false;
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
       
        SqlConnection con = new SqlConnection("user id=sa;password=sqlserver;database=shoppingmall;data source=DATASERVER");
        SqlDataReader dr;
        con.Open();
        SqlCommand cmd = new SqlCommand("select password from login where uname='" + Txtuname.Text + "'and PhoneNumber= " + Txtph.Text + "", con);


        dr = cmd.ExecuteReader();
        if (dr.Read())
        {
            Lblpwd.Visible = true;
            Txtpwd.Visible = true;
            Txtpwd.Text = Convert.ToString(dr["password"]);
        }



       
    }
}
