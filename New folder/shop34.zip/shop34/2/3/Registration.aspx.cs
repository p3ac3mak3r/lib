using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("server=DATASERVER;database=shoppingmall;user id=sa;password=sqlserver");
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        SqlDataAdapter da = new SqlDataAdapter("select UserId from login",con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
        con.Close();
        int i = GridView1.Rows.Count;
        i++;
        ViewState["UserId"] = i;
    }
    protected void Btnsubmit_Click(object sender, EventArgs e)
    {
        int j = (int)ViewState["UserId"];
        con.Open();
        SqlCommand cmd = new SqlCommand("insert into login values('"+j+"','"+Txtuname.Text+"','"+Txtpwd.Text+"','"+Txtph.Text+"')",con);
        cmd.ExecuteNonQuery();
       
        con.Close();
        Response.Redirect("Userlogin.aspx");
        
    }
}


    

