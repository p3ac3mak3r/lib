using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Welcome : System.Web.UI.Page
{
     
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Lnkmobiles_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Mobiles");
    }
    protected void Lnktoys_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Toys");
    }
    protected void Lnkjewel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Jewellery");
    }
    protected void Lnkbaby_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Baby");
    }
    protected void Lnkbeauty_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Beauty");
    }
    protected void Lnkfurniture_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Furniture");
    }
    protected void Lnkelectronics_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Electronics");
    }
    protected void Lnkmusic_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Music");
    }
    protected void Lnkshampines_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Shampines");
    }
    protected void LnkSports_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=SportingGoods");
    }
    protected void Lnkhardware_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=HardwareTools");
    }
    protected void Lnkbooks_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Books");
    }
    protected void Lnkvideogames_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=VideoGames");
    }
    protected void Lnksoftwares_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=Softwares");
    }
    protected void Lnktravel_Click(object sender, EventArgs e)
    {
        Response.Redirect("Itemsdisplay.aspx?Producttype=TravelBags");
    }
}
