/*!
 * Ajax IM
 * Ajax Instant Messeneger
 * http://ajaxim.com/
 *
 * Copyright 2010, Joshua Gross
 * Licensed under the MIT license.
 * [License URL]
 *
 * Includes:
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * v2.1, Copyright 2002, Paul Johnston
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info
 *
 * Date Format 1.2.3
 * http://blog.stevenlevithan.com/archives/date-time-format
 * Copyright 2009 Steven Levithan 
 * MIT license
 */
(function($) {
